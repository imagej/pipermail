package plugins;

import java.util.List;

import org.scijava.Context;
import org.scijava.plugin.Plugin;
import org.scijava.plugin.PluginService;

import imagej.command.Command;
import imagej.command.ContextCommand;
import imagej.module.process.PreprocessorPlugin;

@Plugin(menuPath = "Plugins>Alida>CreateContextCommand", headless = true, type = Command.class)
public class CreateContextCommand extends ContextCommand {

	
	@Override
	public void run() {
		Context context = this.getContext();
		PluginService pluginService = context.getService(PluginService.class);
		List<PreprocessorPlugin> servicePreProcs =  pluginService.createInstancesOfType( PreprocessorPlugin.class);
		System.out.println("CreateContextCommand found " + servicePreProcs.size() + " preprocessors");
		for ( PreprocessorPlugin pre : servicePreProcs ) {
			System.out.println("pre " + pre);
		}
		
		imagej.ImageJ IJ = new imagej.ImageJ();
	}
}
