package mainroutine;

public class CreateContext {

	public static void main(String[] args) {
		System.out.println("about to create first context");
		imagej.ImageJ IJ = new imagej.ImageJ();
		System.out.println("done");
	
		System.out.println("about to create second context");	
		IJ = new imagej.ImageJ();
		System.out.println("done");
	}

}
