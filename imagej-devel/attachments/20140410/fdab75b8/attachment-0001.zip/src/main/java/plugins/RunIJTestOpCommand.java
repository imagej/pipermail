package plugins;

import java.util.List;

import org.scijava.Context;
import org.scijava.plugin.Plugin;
import org.scijava.plugin.PluginService;

import imagej.command.Command;
import imagej.command.CommandInfo;
import imagej.command.CommandModule;
import imagej.command.CommandService;
import imagej.command.ContextCommand;
import imagej.module.Module;
import imagej.module.ModuleException;
import imagej.module.process.InitPreprocessor;
import imagej.module.process.PreprocessorPlugin;
import io.scif.services.InitializeService;

@Plugin(menuPath = "Plugins>Alida>RunIJTestOp", headless = true, type = Command.class)
public class RunIJTestOpCommand extends ContextCommand {

	
	@Override
	public void run() {
		// 
		
		
		// try to do it your own way
		Context context = this.getContext();
		
//		CommandService commandSerice = context.getService(CommandService.class);	
//		CommandInfo testopInfo = commandSerice.getCommand(IJTestOp.class);
		CommandInfo testopInfo = new CommandInfo(IJTestOp.class.getName());

		System.out.println("RunIJOpTest::run created commandinfo: " + testopInfo);
		
		CommandModule testopModule;
		try {
			testopModule = (CommandModule) testopInfo.createModule();
			
			System.out.println("RunIJOpTest::run created module: " + testopModule);
			
			PluginService pluginService = context.getService(PluginService.class);
			List<PreprocessorPlugin> servicePreProcs =  pluginService.createInstancesOfType( PreprocessorPlugin.class);
			System.out.println("RunIJOpTest::run found " + servicePreProcs.size() + " preprocessors");
			for ( PreprocessorPlugin pre : servicePreProcs ) {
				System.out.print("RunIJOpTest::run process with  " + pre);
				if ( ! InitPreprocessor.class.isAssignableFrom(pre.getClass())) {
					System.out.println();
					pre.process(testopModule);
				} else {
					System.out.println( " skipped");
				}
			}
			
			testopModule.getCommand().run();

		} catch (ModuleException e) {
			System.out.println( "RunIJOpTest::run  failed to create module");
			e.printStackTrace();
		}
		
	}

}
