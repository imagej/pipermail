package plugins;

import imagej.command.Command;
import imagej.command.ContextCommand;
import imagej.data.display.ImageDisplayService;

import org.scijava.ItemIO;
import org.scijava.plugin.Plugin;
import org.scijava.plugin.Parameter;


/**
 * @author Stefan Posch
 */
@Plugin(menuPath = "Plugins>Alida>IjTestOp", headless = true, type = Command.class,
  initializer = "initializer")
public class IJTestOp extends ContextCommand implements Command {

	@Parameter(type=ItemIO.INPUT)
	int ivalIn;

	@Parameter(type=ItemIO.OUTPUT)
	int ivalOut;
	
	@Parameter(type=ItemIO.INPUT)
	ImageDisplayService imageDisplayService;
	
	@Override
	public void run() {
		System.out.println( "plugins.IJTestOp::operate imageDisplayService = " + imageDisplayService);
		System.out.println( "plugins.IJTestOp::operate ivalIn = " + ivalIn);
		ivalOut = ivalIn;
	}
	
	public void initializer() {
		System.out.println( "plugins.IJTestOp::initializer");
	}

}
