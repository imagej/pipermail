package mainroutine;

import imagej.command.CommandInfo;
import imagej.command.CommandModule;
import imagej.module.Module;
import imagej.module.ModuleException;
import imagej.module.process.InitPreprocessor;
import imagej.module.process.PreprocessorPlugin;

import java.util.List;
import java.util.concurrent.Future;

import org.scijava.plugin.PluginService;

import plugins.IJTestOp;

public class RunTestOp {

	public static void main(String[] args) {
		System.out.println("about to create context");
		imagej.ImageJ ij = new imagej.ImageJ();
		System.out.println("done");
	
		// ==========================================================
		// invoke with Args
		Future<CommandModule> future = ij.command().run(IJTestOp.class, true, "ivalIn", 123);
		Module module = ij.module().waitFor(future);
		System.out.println( "ovalIn = " + module.getOutput("ivalOut"));
		
		// ==========================================================
		// invoke by hand
		CommandInfo testopInfo = new CommandInfo(IJTestOp.class.getName());

		System.out.println("RunIJOpTest::run created commandinfo: " + testopInfo);
		
		CommandModule testopModule;
		try {
			testopModule = (CommandModule) testopInfo.createModule();
			
			System.out.println("RunIJOpTest::run created module: " + testopModule);
			
			PluginService pluginService = ij.context().getService(PluginService.class);
			List<PreprocessorPlugin> servicePreProcs =  pluginService.createInstancesOfType( PreprocessorPlugin.class);
			System.out.println("RunIJOpTest::run found " + servicePreProcs.size() + " preprocessors");
			for ( PreprocessorPlugin pre : servicePreProcs ) {
				System.out.print("RunIJOpTest::run process with  " + pre);
				if ( ! InitPreprocessor.class.isAssignableFrom(pre.getClass())) {
					System.out.println();
					pre.process(testopModule);
				} else {
					System.out.println( " skipped");
				}
			}
			
			testopModule.setInput("ivalIn", 321);
			testopModule.getCommand().run();
			System.out.println( "ovalIn = " + testopModule.getOutput("ivalOut"));

		} catch (ModuleException e) {
			System.out.println( "RunIJOpTest::run  failed to create module");
			e.printStackTrace();
		}
		
	}

}
